var playerCurrentWood = 100;

var playerStartingBaseX;
var playerStartingBaseY;

var playerCurrentSupply = 0;
var playerSupplyMax = 6;

// player needs to build prerequisite buildings
var playerCampHasBeenMade = false;
var playerBarracksHasBeenMade = false;
var madeFirstWorker = false;
var madeSecondWorker = false;
var madeThirdWorker = false;
var madeFourthWorker = false;
var madeFifthWorker = false;
var madeSixthWorker = false;
var madeSeventhWorker = false;
var doneShowingTips = false;
